﻿using Application.DTOs.Account;
using Application.Interfaces.Account;
using Infrastructure.Account.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;
        private readonly ILogger<WeatherForecastController> _logger;

        public AccountController(IAccountService accountService, ILogger<WeatherForecastController> logger)
        {
            _accountService = accountService;
            _logger = logger;
        }



        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> GetTokenAsync(LoginModel loginModel)
        {
            
            //var ipAddress = GenerateIPAddress();
            var token = await _accountService.LoginAsync(loginModel);
            if (token == null)
            {
                var msg = "Invalid credential!";
                return Ok(msg);
            }
            
            return Ok(token);
        }

        [HttpPost("register")]
        [AllowAnonymous]
        public async Task<IActionResult> RegisterAsync(RegisterModel register)
        {
            var origin = Request.Headers["origin"];
            var ms = await _accountService.RegisterAsync(register, origin);
            return Ok(ms);
        }


        [HttpGet("confirm-email")]
        
        public async Task<IActionResult> ConfirmEmailAsync([FromQuery] string userId, [FromQuery] string code)
        {
            var ms = await _accountService.ConfirmEmailAsync(userId, code);
            return Ok(ms);
        }

        [HttpPost("forgot-password")]
        [AllowAnonymous]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordModel model)
        {
            var origin = Request.Headers["origin"];
            var list=await _accountService.ForgotPasswordAsync(model,origin);
            return Ok(list);
        }


        [HttpPost("reset-password")]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(ResetPasswordModel model)
        {
            return Ok(await _accountService.ResetPasswordAsync(model));
        }

        [HttpPost("change-password")]
        
        public async Task<IActionResult> ChangePassword(ChangePasswordModel model)
        {
            return Ok(await _accountService.ChangePasswordAsync(model));
        }




        [HttpPost("update-profile")]
        
        public async Task<IActionResult> UpdateProfile(UpdateProfileModel user)
        {
            var list=await _accountService.UpdateProfileAsync(user);
            return Ok(list);
        }


        [HttpPost("update-profile-image")]
        
        public async Task<IActionResult> UploadProfileImage(IFormFile file, string email)
        {
            var list=await _accountService.UpdateProfileImageAsync(file,email);
            return Ok(list);
        }



        [HttpPost("change-email")]
        [AllowAnonymous]
        public async Task<IActionResult> ChangeEmail(ChangeEmailModel model)
        {
            var origin = Request.Headers["origin"];
            var list = await _accountService.ChangeEmailAsync(model, origin);
            return Ok(list);
        }


        [HttpGet("change-email-confirm")]
        [AllowAnonymous]
        public async Task<IActionResult> ChangeEmailConfirm([FromQuery] string userId, [FromQuery] string email, [FromQuery] string code)
        {
            var list = await _accountService.ConfirmEmailChangeAsync(userId,email,code);
            return Ok(list);
        }



    }
}
