﻿using Application.DTOs.Settings;
using Application.Interfaces.Account;
using Application.Interfaces.Shared;
using Infrastructure.Account.Models;
using Infrastructure.Account.Services;
using Infrastructure.Context;
using Infrastructure.Shared.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddContextInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddControllersWithViews();

            services.Configure<JWTSettings>(configuration.GetSection("JWTSettings"));

            //services.AddDbContext<AccountDbContext>(options => options.UseSqlServer(configuration.GetConnectionString("IdentityConnection")));

            services.AddDbContext<AccountDbContext>(options => options.UseSqlServer(configuration.GetConnectionString("IdentityConnection")));


            services.AddIdentity<ApplicationUser, IdentityRole>().AddEntityFrameworkStores<AccountDbContext>().AddDefaultUI().AddDefaultTokenProviders();




        }


        public static void AddInfrastructure(this IServiceCollection services)
        {
            services.AddTransient<IAccountService, AccountService>();

        }




        public static void AddSharedInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<MailSettings>(configuration.GetSection("MailSettings"));
            services.AddTransient<IMailService, MailService>();

        }
    }
}
