﻿using Application.DTOs.Account;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Interfaces.Account
{
    public interface IAccountService
    {
        Task<string> RegisterAsync(RegisterModel model, string origin);
        Task<Response> LoginAsync(LoginModel model);

        Task<string> ConfirmEmailAsync(string userId, string code);

        Task<string> ForgotPasswordAsync(ForgotPasswordModel model, string origin);

        Task<string> ResetPasswordAsync(ResetPasswordModel model);
        Task<string> ChangePasswordAsync(ChangePasswordModel model);
        Task<string> ChangeEmailAsync(ChangeEmailModel model,string orgin);
        Task<string> ConfirmEmailChangeAsync(string userId, string email, string code);
        Task<string> UpdateProfileAsync(UpdateProfileModel user);
        Task<string> UpdateProfileImageAsync(IFormFile file, string email);
    }
}
