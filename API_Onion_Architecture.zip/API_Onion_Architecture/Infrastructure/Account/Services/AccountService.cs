﻿using Application.DTOs.Account;
using Application.DTOs.Mail;
using Application.DTOs.Settings;
using Application.Enums;
using Application.Exceptions;
using Application.Interfaces.Account;
using Application.Interfaces.Shared;
using Infrastructure.Account.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Account.Services
{
    public class AccountService : IAccountService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly JWTSettings _jwtSettings;
        private readonly IMailService _mailService;

        public AccountService(UserManager<ApplicationUser> userManager,
            RoleManager<IdentityRole> roleManager,
            IOptions<JWTSettings> jwtSettings,
           SignInManager<ApplicationUser> signInManager,
           IMailService mailService)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _jwtSettings = jwtSettings.Value;
            _signInManager = signInManager;
            _mailService = mailService;
        }


        public async Task<Response> LoginAsync(LoginModel model)
        {
            
            var response = new Response();
            var user = await _userManager.FindByEmailAsync(model.Email);
            


            //if (!await _userManager.IsInRoleAsync(user, Role.Basic.ToString()))
            //{
            //    await _userManager.AddToRoleAsync(user, Role.Basic.ToString());
            //}
            if (user.IsActive != true)
            {
                user.IsActive = true;
                await _userManager.UpdateAsync(user);
            }
            var result = await _signInManager.PasswordSignInAsync(user.UserName, model.Password, false, lockoutOnFailure: false);
            if (result.Succeeded)
            {
                JwtSecurityToken jwtSecurityToken = await GenerateJWToken(user);
                response.Id = user.Id;
                response.JWToken = new JwtSecurityTokenHandler().WriteToken(jwtSecurityToken);
                response.IssuedOn = jwtSecurityToken.ValidFrom.ToLocalTime();
                response.ExpiresOn = jwtSecurityToken.ValidTo.ToLocalTime();
                response.Email = user.Email;
                var rolesList = await _userManager.GetRolesAsync(user).ConfigureAwait(false);
                response.Roles = rolesList.ToList();
                response.IsVerified = user.EmailConfirmed;
                return response;
            }
            return null;
            
        }



        private async Task<JwtSecurityToken> GenerateJWToken(ApplicationUser user)
        {
            var userClaims = await _userManager.GetClaimsAsync(user);
            var roles = await _userManager.GetRolesAsync(user);
            var roleClaims = new List<Claim>();
            for (int i = 0; i < roles.Count; i++)
            {
                roleClaims.Add(new Claim("roles", roles[i]));
            }
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.UserName),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim("uid", user.Id),
                new Claim("first_name", user.FirstName),
                new Claim("last_name", user.LastName),
                new Claim("full_name", $"{user.FirstName} {user.LastName}")
            }
            .Union(userClaims)
            .Union(roleClaims);
            return JWTGeneration(claims);
        }

        private JwtSecurityToken JWTGeneration(IEnumerable<Claim> claims)
        {
            var symmetricSecurityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key));
            var signingCredentials = new SigningCredentials(symmetricSecurityKey, SecurityAlgorithms.HmacSha256);

            var jwtSecurityToken = new JwtSecurityToken(
                issuer: _jwtSettings.Issuer,
                audience: _jwtSettings.Audience,
                claims: claims,
                notBefore: DateTime.UtcNow,
                expires: DateTime.UtcNow.AddMinutes(_jwtSettings.DurationInMinutes),
                signingCredentials: signingCredentials);
            return jwtSecurityToken;
        }




        public async Task<string> RegisterAsync(RegisterModel model, string origin)
        {
            var userExist = await _userManager.FindByEmailAsync(model.Email);
            if (userExist != null)
            {
                throw new ApiException($"Username '{model.Email}' is already taken.");

            }

            var user = new ApplicationUser
            {
                Email = model.Email,
                FirstName = model.FirstName,
                LastName = model.LastName,
                UserName = model.Email
            };
            var userWithSameEmail = await _userManager.FindByEmailAsync(model.Email);
            if (userWithSameEmail == null)
            {
                var result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(user, Role.Basic.ToString());
                    var verificationUri = await SendVerificationEmail(user, origin);
                    //TODO: Attach Email Service here and configure it via appsettings
                    await _mailService.SendAsync(new MailRequest() { From = "verifyotp9@gmail.com", To = user.Email, Body = $"Please confirm your account by <a href='{verificationUri}'>clicking here</a>.", Subject = "Confirm Registration" });
                    
                    return $"User Registered. Confirmation Mail has been delivered to your Mailbox. Please confirm your account by visiting this URL {verificationUri}";
                }
                else
                {
                    throw new ApiException($"{result.Errors}");
                }
            }
            else
            {
                throw new ApiException($"Email {model.Email } is already registered.");
            }
        }


        private async Task<string> SendVerificationEmail(ApplicationUser user, string origin)
        {
            var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
            code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code));
            var route = "api/account/confirm-email/";
            var _enpointUri = new Uri(string.Concat($"{origin}/", route));
            var verificationUri = QueryHelpers.AddQueryString(_enpointUri.ToString(), "userId", user.Id);
            verificationUri = QueryHelpers.AddQueryString(verificationUri, "code", code);
            //Email Service Call Here
            return verificationUri;
        }


        public async Task<string> ConfirmEmailAsync(string userId, string code)
        {
            var user = await _userManager.FindByIdAsync(userId);
            code = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(code));
            var result = await _userManager.ConfirmEmailAsync(user, code);
            if (result.Succeeded)
            {
                return $"Account Confirmed for {user.Email}. You can now use the /api/identity/token endpoint to generate JWT."; ;

                //return new Messages { Message = $"Account Confirmed for {user.Email}. You can now use the /api/identity/token endpoint to generate JWT.", Status = "Success" }.ToString();

                //return Task<string>.Success(user.Id, message: $"Account Confirmed for {user.Email}. You can now use the /api/identity/token endpoint to generate JWT.");
            }
            else
            {
                throw new ApiException($"An error occured while confirming {user.Email}.");
            }
        }




        public async Task<string> ForgotPasswordAsync(ForgotPasswordModel model, string origin)
        {
            var account = await _userManager.FindByEmailAsync(model.Email);

            // always return ok response to prevent email enumeration
            if (account == null) return $"{model.Email} is invalid. please check the email id";

            var code = await _userManager.GeneratePasswordResetTokenAsync(account);
            var route = "api/account/reset-password/";
            var _enpointUri = new Uri(string.Concat($"{origin}/", route));
            var emailRequest = new MailRequest()
            {
                Body = $"You reset token is - {code}",
                To = model.Email,
                Subject = "Reset Password",
            };
            await _mailService.SendAsync(emailRequest);
            return $"You reset token has been delivered to your Mailbox. Please reset password";
        }





        public async Task<string> ResetPasswordAsync(ResetPasswordModel model)
        {
            var account = await _userManager.FindByEmailAsync(model.Email);
            if (account == null)
            {
                return $"{model.Email}   is invalid. please check the email Id";
            }
            //if (account == null) throw new ApiException($"No Accounts Registered with {model.Email}.");
            var result = await _userManager.ResetPasswordAsync(account, model.Token, model.Password);
            if (result.Succeeded)
            {
                return "Your password has been reset. Please login";
            }
            else
            {
                throw new ApiException($"Error occured while reseting the password.");
            }
        }


        public async Task<string> ChangePasswordAsync(ChangePasswordModel model)
        {

            var account = await _userManager.FindByEmailAsync(model.Email);
            if (account == null)
            {
                return $"{model.Email} is invalid. please check the email Id";
            }
            //if (account == null) throw new ApiException($"No Accounts Registered with {model.Email}.");
            var result = await _userManager.ChangePasswordAsync(account, model.OldPassword,model.NewPassword);
            if (result.Succeeded)
            {
                return "Your password has been changed.";
            }
            else
            {
                throw new ApiException($"Error occured while reseting the password.");
            }
        }






        public async Task<string> UpdateProfileAsync(UpdateProfileModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);

            if (user != null)
            {
                if (model.FirstName==null)
                {
                    model.FirstName = user.FirstName;
                }
                if (model.LastName == null)
                {
                    model.LastName = user.LastName;
                }
                if (model.Username == null)
                {
                    model.Username = user.UserName;
                }
                if (model.PhoneNumber == null)
                {
                    model.PhoneNumber = user.PhoneNumber;
                }
                user.FirstName = model.FirstName;
                user.LastName = model.LastName;
                user.PhoneNumber = model.PhoneNumber;
                user.UserName = model.Email;
                user.Email = model.Email;

                await _userManager.UpdateAsync(user);
                return "Your profile has been updated!";

            }
            return "Invalid credential!";



        }

        public async Task<string> UpdateProfileImageAsync(IFormFile file,string email)
        {
            var user = await _userManager.FindByEmailAsync(email);
            if (user != null)
            {
                using (var dataStream = new MemoryStream())
                {
                    await file.CopyToAsync(dataStream);
                    user.ProfilePicture = dataStream.ToArray();
                }
                await _userManager.UpdateAsync(user);
                return "Your profile picture has been updated";
            }
            return "Invalid Credential!";


        }






        public async Task<string> ChangeEmailAsync(ChangeEmailModel model, string origin)
        {
            var user = await _userManager.FindByEmailAsync(model.OldEmail);


            if (user == null)
            {
                return $"{model.OldEmail} is not registered please check the email id";
            }
            bool IsEmailConfirmed = await _userManager.IsEmailConfirmedAsync(user);
            if (IsEmailConfirmed == true)
            {
                var email = await _userManager.GetEmailAsync(user);
                if (model.NewEmail != email)
                {
                    

                    var userId = await _userManager.GetUserIdAsync(user);
                    var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                    code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code));
                    var route = "api/account/change-email-confirm/";
                    var _enpointUri = new Uri(string.Concat($"{origin}/", route));
                    var verificationUri = QueryHelpers.AddQueryString(_enpointUri.ToString(), "userId", user.Id);
                    verificationUri = QueryHelpers.AddQueryString(verificationUri, "email", model.NewEmail);
                    verificationUri = QueryHelpers.AddQueryString(verificationUri, "code", code);
                    

                    var mailRequest = new MailRequest
                    {
                        Body = $"Please confirm your account by <a href='{verificationUri}'>clicking here</a>.",
                        From = "verifyotp9@gmail.com",
                        To = model.NewEmail,
                        Subject = "Confirm Registration"
                    };

                    await _mailService.SendAsync(mailRequest);

                    return $"{code}, {userId}, {model.NewEmail}  Confirmation link to change email sent. Please check your email.";
                }



            }
            return "Your email is unchanged.";


        }



        public async Task<string> ConfirmEmailChangeAsync(string userId, string email, string code)
        {
            if (userId == null || email == null || code == null)
            {
                return "Invalid credential!";
            }



            var user = await _userManager.FindByIdAsync(userId);
            //code = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(code));
            //var result = await _userManager.ConfirmEmailAsync(user, code);
            
            if (user == null)
            {
                return "Error changing email";
            }

            code = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(code));
            var result = await _userManager.ChangeEmailAsync(user, email, code);
            if (!result.Succeeded)
            {
                return "Error changing email.";
            }

            await _signInManager.RefreshSignInAsync(user);
            return "Thank you for confirming your email change.";
        }


    }
}
